def stockleft():
    print('库存是20件')