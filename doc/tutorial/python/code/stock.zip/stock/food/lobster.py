def stockleft():
    print('库存是100件')