def stockleft():
    print('库存是30件')