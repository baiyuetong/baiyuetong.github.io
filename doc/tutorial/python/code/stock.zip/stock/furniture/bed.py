def stockleft():
    print('库存是10件')