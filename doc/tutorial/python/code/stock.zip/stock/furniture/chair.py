def stockleft():
    print('库存是1200件')