def beefStock():
    print('库存是50件')