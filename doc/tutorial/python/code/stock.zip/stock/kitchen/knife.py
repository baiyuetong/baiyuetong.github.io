def stockleft():
    print('库存是40件')